package com.example.otchetfinansov;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class FinanceManager {
    private static final String PREFERENCES_NAME = "FinancesPreferences";
    private static final String KEY_TRANSACTIONS = "transactions";
    private static final String KEY_INCOME = "income";
    private static final String KEY_EXPENSE = "expense";
    private static SharedPreferences sharedPreferences;

    public enum TransactionType {
        INCOME,
        EXPENSE
    }

    public FinanceManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    }

    // Метод для сохранения транзакции
    public void saveTransaction(float amount, TransactionType type) {
        Transaction transaction = new Transaction(String.valueOf(amount), type.name());
        List<Transaction> transactions = getAllTransactions();
        transactions.add(transaction);
        saveTransactions(transactions);

        // Обновляем общую сумму доходов или расходов
        if (type == TransactionType.INCOME) {
            float income = getIncome() + amount;
            saveIncome(income);
        } else if (type == TransactionType.EXPENSE) {
            float expense = getExpense() + amount;
            saveExpense(expense);
        }
    }

    // Метод для получения всех транзакций
    public static List<Transaction> getAllTransactions() {
        String transactionsJson = sharedPreferences.getString(KEY_TRANSACTIONS, null);
        Type type = new TypeToken<List<Transaction>>(){}.getType();
        List<Transaction> transactions;
        if (transactionsJson != null) {
            transactions = new Gson().fromJson(transactionsJson, type);
        } else {
            transactions = new ArrayList<>();
        }
        return transactions;
    }

    // Метод для сохранения списка транзакций
    private void saveTransactions(List<Transaction> transactions) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String transactionsJson = new Gson().toJson(transactions);
        editor.putString(KEY_TRANSACTIONS, transactionsJson);
        editor.apply();
    }

    // Метод для очистки списка транзакций
    public void clearAllTransactions() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(KEY_TRANSACTIONS);
        editor.apply();
    }

    // Метод для получения доходов
    public float getIncome() {
        return sharedPreferences.getFloat(KEY_INCOME, 0.0f);
    }

    // Метод для сохранения доходов
    public void saveIncome(float income) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat(KEY_INCOME, income);
        editor.apply();
    }

    // Метод для получения расходов
    public float getExpense() {
        return sharedPreferences.getFloat(KEY_EXPENSE, 0.0f);
    }

    // Метод для сохранения расходов
    public void saveExpense(float expense) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat(KEY_EXPENSE, expense);
        editor.apply();
    }
}
