package com.example.otchetfinansov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class Setting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);

        Button npHomeBut = findViewById(R.id.npHomeBut);
        Button npTranzakBut = findViewById(R.id.npTranzakBut);
        Button npSetBut = findViewById(R.id.npSetBut);

        //Нижний бар
        //Главная
        npHomeBut.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View v){
                Intent intent = new Intent(Setting.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //Транзакции
        npTranzakBut.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View v){
                Intent intent = new Intent(Setting.this, CardViewActivity.class);
                startActivity(intent);
            }
        });

        //Настройки
        npSetBut.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View v){
                Intent intent = new Intent(Setting.this, Setting.class);
                startActivity(intent);
            }
        });

    }
}

