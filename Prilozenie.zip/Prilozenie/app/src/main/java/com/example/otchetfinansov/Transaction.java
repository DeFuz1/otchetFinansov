package com.example.otchetfinansov;

import java.io.Serializable;

public class Transaction implements Serializable {

    private String amount;

    private String category;

    public Transaction(String amount, String category) {
        this.amount = amount;
        this.category = category;
    }


    public String getAmount() {
        return amount;
    }

    public String getCategory() {
        return category;
    }

}
