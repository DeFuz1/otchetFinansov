package com.example.otchetfinansov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class NewDoxodActivity extends AppCompatActivity {

    private FinanceManager financeManager;

    private EditText SumDoxod, CategoryD;
    private Button DoxodBut;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_doxod);

        // Инициализация financeManager
        financeManager = new FinanceManager(this);

        // Инициализация элементов управления
        SumDoxod = findViewById(R.id.SumDoxod);
        CategoryD = findViewById(R.id.CategoryD);
        DoxodBut = findViewById(R.id.DoxodBut);
        textView = findViewById(R.id.textView);
        Button npHomeBut = findViewById(R.id.npHomeBut);
        Button npTranzakBut = findViewById(R.id.npTranzakBut);
        Button npSetBut = findViewById(R.id.npSetBut);
        Button delhist = findViewById(R.id.delhist);

        // Удалить историю
        delhist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Обновление отображения суммы доходов в textView
                float totalIncome = financeManager.getIncome();
                textView.setText(String.valueOf(totalIncome));
            }
        });

        // Обработчик нажатия на кнопку "Добавить доход"
        DoxodBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Получение суммы дохода и категории
                String sum = SumDoxod.getText().toString();
                String category = CategoryD.getText().toString();
                float incomeAmount = Float.parseFloat(sum);

                // Сохранение транзакции
                financeManager.saveTransaction(incomeAmount, FinanceManager.TransactionType.INCOME);

                // Передаем данные на другую страницу
                Intent intent = new Intent(NewDoxodActivity.this, CardViewActivity.class);
                intent.putExtra("textViewAmount", sum);
                intent.putExtra("textViewCategory", category);
                startActivity(intent);

                // Получение обновленной суммы доходов и отображение в textView
                float totalIncome = financeManager.getIncome();
                textView.setText(String.valueOf(totalIncome));

                // Установка цвета текста
                textView.setTextColor(getResources().getColor(android.R.color.holo_green_light));
            }
        });

        //Нижний бар
        //Главная
        npHomeBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewDoxodActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //Транзакции
        npTranzakBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewDoxodActivity.this, CardViewActivity.class);
                startActivity(intent);
            }
        });

        //Настройки
        npSetBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewDoxodActivity.this, Setting.class);
                startActivity(intent);
            }
        });
    }
}



