package com.example.otchetfinansov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CardViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cardview);

        // Инициализация кнопок
        Button npHomeBut = findViewById(R.id.npHomeBut);
        Button npTranzakBut = findViewById(R.id.npTranzakBut);
        Button npSetBut = findViewById(R.id.npSetBut);

        // Получение данных из Intent, переданных из предыдущей активности
        Intent intent = getIntent();
        if (intent != null) {
            String amount = intent.getStringExtra("textViewAmount");
            String category = intent.getStringExtra("textViewCategory");

            // Отображение данных на экране, например, в TextView
            TextView textViewAmount = findViewById(R.id.textViewAmount);
            TextView textViewCategory = findViewById(R.id.textViewCategory);
            textViewAmount.setText(amount);
            textViewCategory.setText(category);
        }
        // Инициализация layout
        LinearLayout layout = findViewById(R.id.transactionDetailsContainer);
        // Получаем экземпляр FinanceManager
        FinanceManager financeManager = new FinanceManager(this);

// Получаем список всех транзакций
        ArrayList<Transaction> transactions = (ArrayList<Transaction>) FinanceManager.getAllTransactions();

// Получаем контейнер, в который будем добавлять транзакции
        LinearLayout transactionContainer = findViewById(R.id.transactionDetailsContainer);

// Очищаем контейнер перед добавлением новых транзакций
        transactionContainer.removeAllViews();

// Добавляем каждую транзакцию в отдельный контейнер и добавляем этот контейнер в основной контейнер
        for (Transaction transaction : transactions) {
            // Создаем новый контейнер для текущей транзакции
            LinearLayout transactionLayout = new LinearLayout(this);
            transactionLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            transactionLayout.setOrientation(LinearLayout.VERTICAL);

            // Создаем TextView для отображения суммы транзакции
            TextView amountTextView = new TextView(this);
            amountTextView.setText("Сумма: " + transaction.getAmount());
            transactionLayout.addView(amountTextView);

            // Создаем TextView для отображения категории транзакции
            TextView categoryTextView = new TextView(this);
            categoryTextView.setText("Категория: " + transaction.getCategory());
            transactionLayout.addView(categoryTextView);

            // Добавляем созданный контейнер с транзакцией в основной контейнер
            transactionContainer.addView(transactionLayout);
        }




        // Обработчики нажатия на кнопки
        npHomeBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardViewActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        npTranzakBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardViewActivity.this, CardViewActivity.class);
                startActivity(intent);
            }
        });

        npSetBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardViewActivity.this, Setting.class);
                startActivity(intent);
            }
        });
    }
}

