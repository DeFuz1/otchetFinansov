package com.example.otchetfinansov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        Button btnDox = findViewById(R.id.btnDox);
        Button btnRas = findViewById(R.id.btnRas);
        Button DelHBut = findViewById(R.id.DelHBut);
        Button npHomeBut = findViewById(R.id.npHomeBut);
        Button npTranzakBut = findViewById(R.id.npTranzakBut);
        Button npSetBut = findViewById(R.id.npSetBut);

        btnDox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewDoxodActivity.class);
                startActivity(intent);
            }
        });

        btnRas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewRacxodActivity.class);
                startActivity(intent);
            }
        });

        DelHBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Очистка истории доходов и расходов
                FinanceManager financeManager = new FinanceManager(MainActivity.this);
                financeManager.clearAllTransactions();
                financeManager.saveIncome(0.0f);
                financeManager.saveExpense(0.0f);

                // Переход обратно на главный экран
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //Нижний бар
        //Главная
        npHomeBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //Транзакции
        npTranzakBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CardViewActivity.class);
                startActivity(intent);
            }
        });

        //Настройки
        npSetBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Setting.class);
                startActivity(intent);
            }
        });

    }
}
