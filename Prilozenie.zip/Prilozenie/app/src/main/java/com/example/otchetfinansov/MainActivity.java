package com.example.otchetfinansov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.otchetfinansov.NewDoxodActivity;
import com.example.otchetfinansov.NewRacxodActivity;
import com.example.otchetfinansov.R;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private Button btnDox, btnRas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        textView = findViewById(R.id.textView);
        btnDox = findViewById(R.id.btnDox);
        btnRas = findViewById(R.id.btnRas);

        // Set up click listeners
        btnDox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create Intent for navigating to NewDoxodActivity
                Intent intent = new Intent(MainActivity.this, NewDoxodActivity.class);
                startActivity(intent);
            }
        });

        btnRas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create Intent for navigating to NewRacxodActivity
                Intent intent = new Intent(MainActivity.this, NewRacxodActivity.class);
                startActivity(intent);
            }
        });
    }
}
