package com.example.otchetfinansov;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class NewRacxodActivity extends AppCompatActivity {

    private EditText sumRacxod, categoryR;
    private Button racxodBut;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_racxod);

        // Инициализация элементов управления
        sumRacxod = findViewById(R.id.SumRacxod);
        categoryR = findViewById(R.id.CategoryR);
        racxodBut = findViewById(R.id.RacxodBut);
        textView = findViewById(R.id.textView);

        // Обработчик нажатия на кнопку "Добавить расход"
        racxodBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Получение суммы расхода и категории из полей EditText
                String sum = sumRacxod.getText().toString();
                String category = categoryR.getText().toString();

                // Рассчет суммарного расхода и вывод в TextView
                // Здесь нужно добавить ваш логический код для расчета суммарного расхода
                // В данном примере просто присваиваем сумму введенную пользователем
                textView.setText(sum);
            }
        });
    }
}
