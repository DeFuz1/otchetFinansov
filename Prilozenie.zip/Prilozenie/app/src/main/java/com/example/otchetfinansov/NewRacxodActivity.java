package com.example.otchetfinansov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class NewRacxodActivity extends AppCompatActivity {

    private FinanceManager financeManager;

    private EditText SumRacxod, CategoryR;
    private Button RacxodBut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_racxod);

        financeManager = new FinanceManager(this);

        // Инициализация элементов управления
        SumRacxod = findViewById(R.id.SumRacxod);
        CategoryR = findViewById(R.id.CategoryR);
        RacxodBut = findViewById(R.id.RacxodBut);
        Button npHomeBut = findViewById(R.id.npHomeBut);
        Button npTranzakBut = findViewById(R.id.npTranzakBut);
        Button npSetBut = findViewById(R.id.npSetBut);

        // Обработчик нажатия на кнопку "Добавить расход"
        RacxodBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Получение суммы расхода и категории
                String sum = SumRacxod.getText().toString();
                String category = CategoryR.getText().toString();
                float expenseAmount = Float.parseFloat(sum);

                // Сохраняем транзакцию расхода
                financeManager.saveTransaction(expenseAmount, FinanceManager.TransactionType.EXPENSE);

                // Переходим на CardViewActivity
                Intent intent = new Intent(NewRacxodActivity.this, CardViewActivity.class);
                startActivity(intent);
            }
        });

        // Нижний бар
        // Главная
        npHomeBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewRacxodActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Транзакции
        npTranzakBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewRacxodActivity.this, CardViewActivity.class);
                startActivity(intent);
            }
        });

        // Настройки
        npSetBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewRacxodActivity.this, Setting.class);
                startActivity(intent);
            }
        });
    }
}
